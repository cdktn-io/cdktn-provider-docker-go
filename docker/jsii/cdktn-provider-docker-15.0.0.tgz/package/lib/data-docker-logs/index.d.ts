/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDockerLogsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.2.0/docs/data-sources/logs#details DataDockerLogs#details}
    */
    readonly details?: boolean | cdktn.IResolvable;
    /**
    * Discard headers that docker appends to each log entry
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.2.0/docs/data-sources/logs#discard_headers DataDockerLogs#discard_headers}
    */
    readonly discardHeaders?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.2.0/docs/data-sources/logs#follow DataDockerLogs#follow}
    */
    readonly follow?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.2.0/docs/data-sources/logs#id DataDockerLogs#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * If true populate computed value `logs_list_string`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.2.0/docs/data-sources/logs#logs_list_string_enabled DataDockerLogs#logs_list_string_enabled}
    */
    readonly logsListStringEnabled?: boolean | cdktn.IResolvable;
    /**
    * The name of the Docker Container
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.2.0/docs/data-sources/logs#name DataDockerLogs#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.2.0/docs/data-sources/logs#show_stderr DataDockerLogs#show_stderr}
    */
    readonly showStderr?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.2.0/docs/data-sources/logs#show_stdout DataDockerLogs#show_stdout}
    */
    readonly showStdout?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.2.0/docs/data-sources/logs#since DataDockerLogs#since}
    */
    readonly since?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.2.0/docs/data-sources/logs#tail DataDockerLogs#tail}
    */
    readonly tail?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.2.0/docs/data-sources/logs#timestamps DataDockerLogs#timestamps}
    */
    readonly timestamps?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.2.0/docs/data-sources/logs#until DataDockerLogs#until}
    */
    readonly until?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.2.0/docs/data-sources/logs docker_logs}
*/
export declare class DataDockerLogs extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "docker_logs";
    /**
    * Generates CDKTN code for importing a DataDockerLogs resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDockerLogs to import
    * @param importFromId The id of the existing DataDockerLogs that should be imported. Refer to the {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.2.0/docs/data-sources/logs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDockerLogs to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.2.0/docs/data-sources/logs docker_logs} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDockerLogsConfig
    */
    constructor(scope: Construct, id: string, config: DataDockerLogsConfig);
    private _details?;
    get details(): boolean | cdktn.IResolvable;
    set details(value: boolean | cdktn.IResolvable);
    resetDetails(): void;
    get detailsInput(): boolean | cdktn.IResolvable | undefined;
    private _discardHeaders?;
    get discardHeaders(): boolean | cdktn.IResolvable;
    set discardHeaders(value: boolean | cdktn.IResolvable);
    resetDiscardHeaders(): void;
    get discardHeadersInput(): boolean | cdktn.IResolvable | undefined;
    private _follow?;
    get follow(): boolean | cdktn.IResolvable;
    set follow(value: boolean | cdktn.IResolvable);
    resetFollow(): void;
    get followInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get logsListString(): string[];
    private _logsListStringEnabled?;
    get logsListStringEnabled(): boolean | cdktn.IResolvable;
    set logsListStringEnabled(value: boolean | cdktn.IResolvable);
    resetLogsListStringEnabled(): void;
    get logsListStringEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _showStderr?;
    get showStderr(): boolean | cdktn.IResolvable;
    set showStderr(value: boolean | cdktn.IResolvable);
    resetShowStderr(): void;
    get showStderrInput(): boolean | cdktn.IResolvable | undefined;
    private _showStdout?;
    get showStdout(): boolean | cdktn.IResolvable;
    set showStdout(value: boolean | cdktn.IResolvable);
    resetShowStdout(): void;
    get showStdoutInput(): boolean | cdktn.IResolvable | undefined;
    private _since?;
    get since(): string;
    set since(value: string);
    resetSince(): void;
    get sinceInput(): string | undefined;
    private _tail?;
    get tail(): string;
    set tail(value: string);
    resetTail(): void;
    get tailInput(): string | undefined;
    private _timestamps?;
    get timestamps(): boolean | cdktn.IResolvable;
    set timestamps(value: boolean | cdktn.IResolvable);
    resetTimestamps(): void;
    get timestampsInput(): boolean | cdktn.IResolvable | undefined;
    private _until?;
    get until(): string;
    set until(value: string);
    resetUntil(): void;
    get untilInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
