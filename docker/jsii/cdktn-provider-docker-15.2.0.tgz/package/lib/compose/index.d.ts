/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComposeConfig extends cdktn.TerraformMetaArguments {
    /**
    * One or more Compose file paths, equivalent to repeating the `-f` flag with `docker compose`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.4.0/docs/resources/compose#config_paths Compose#config_paths}
    */
    readonly configPaths: string[];
    /**
    * Optional list of env files to load before parsing the Compose configuration. If omitted, Compose uses the default `.env` behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.4.0/docs/resources/compose#env_files Compose#env_files}
    */
    readonly envFiles?: string[];
    /**
    * Optional list of Compose profiles to enable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.4.0/docs/resources/compose#profiles Compose#profiles}
    */
    readonly profiles?: string[];
    /**
    * Optional project directory used as the Compose working directory. If omitted, Compose uses the directory of the first file in `config_paths`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.4.0/docs/resources/compose#project_directory Compose#project_directory}
    */
    readonly projectDirectory?: string;
    /**
    * Optional Compose project name. If omitted, Compose derives the project name the same way as the CLI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.4.0/docs/resources/compose#project_name Compose#project_name}
    */
    readonly projectName?: string;
    /**
    * If `true`, remove containers for services that are no longer present in the Compose configuration during apply and destroy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.4.0/docs/resources/compose#remove_orphans Compose#remove_orphans}
    */
    readonly removeOrphans?: boolean | cdktn.IResolvable;
    /**
    * If `true`, wait until services reach the running or healthy state before returning from apply.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.4.0/docs/resources/compose#wait Compose#wait}
    */
    readonly wait?: boolean | cdktn.IResolvable;
    /**
    * Optional duration for `wait`, for example `30s` or `2m`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.4.0/docs/resources/compose#wait_timeout Compose#wait_timeout}
    */
    readonly waitTimeout?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.4.0/docs/resources/compose docker_compose}
*/
export declare class Compose extends cdktn.TerraformResource {
    static readonly tfResourceType = "docker_compose";
    /**
    * Generates CDKTN code for importing a Compose resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Compose to import
    * @param importFromId The id of the existing Compose that should be imported. Refer to the {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.4.0/docs/resources/compose#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Compose to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.4.0/docs/resources/compose docker_compose} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComposeConfig
    */
    constructor(scope: Construct, id: string, config: ComposeConfig);
    private _configPaths?;
    get configPaths(): string[];
    set configPaths(value: string[]);
    get configPathsInput(): string[] | undefined;
    private _envFiles?;
    get envFiles(): string[];
    set envFiles(value: string[]);
    resetEnvFiles(): void;
    get envFilesInput(): string[] | undefined;
    get id(): string;
    private _profiles?;
    get profiles(): string[];
    set profiles(value: string[]);
    resetProfiles(): void;
    get profilesInput(): string[] | undefined;
    private _projectDirectory?;
    get projectDirectory(): string;
    set projectDirectory(value: string);
    resetProjectDirectory(): void;
    get projectDirectoryInput(): string | undefined;
    private _projectName?;
    get projectName(): string;
    set projectName(value: string);
    resetProjectName(): void;
    get projectNameInput(): string | undefined;
    private _removeOrphans?;
    get removeOrphans(): boolean | cdktn.IResolvable;
    set removeOrphans(value: boolean | cdktn.IResolvable);
    resetRemoveOrphans(): void;
    get removeOrphansInput(): boolean | cdktn.IResolvable | undefined;
    private _wait?;
    get wait(): boolean | cdktn.IResolvable;
    set wait(value: boolean | cdktn.IResolvable);
    resetWait(): void;
    get waitInput(): boolean | cdktn.IResolvable | undefined;
    private _waitTimeout?;
    get waitTimeout(): string;
    set waitTimeout(value: string);
    resetWaitTimeout(): void;
    get waitTimeoutInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
