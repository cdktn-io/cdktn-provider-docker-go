/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDockerContainersConfig extends cdktn.TerraformMetaArguments {
}
export interface DataDockerContainersContainers {
}
export declare function dataDockerContainersContainersToTerraform(struct?: DataDockerContainersContainers): any;
export declare function dataDockerContainersContainersToHclTerraform(struct?: DataDockerContainersContainers): any;
export declare class DataDockerContainersContainersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDockerContainersContainers | undefined;
    set internalValue(value: DataDockerContainersContainers | undefined);
    get command(): string;
    get created(): number;
    get id(): string;
    get image(): string;
    get imageId(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get names(): string[];
    get state(): string;
    get status(): string;
}
export declare class DataDockerContainersContainersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDockerContainersContainersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.4.0/docs/data-sources/containers docker_containers}
*/
export declare class DataDockerContainers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "docker_containers";
    /**
    * Generates CDKTN code for importing a DataDockerContainers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDockerContainers to import
    * @param importFromId The id of the existing DataDockerContainers that should be imported. Refer to the {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.4.0/docs/data-sources/containers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDockerContainers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/kreuzwerker/docker/4.4.0/docs/data-sources/containers docker_containers} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDockerContainersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDockerContainersConfig);
    private _containers;
    get containers(): DataDockerContainersContainersList;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
